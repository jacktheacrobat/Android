package com.example.mod3_ct;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.BlendMode;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {

    // Formatting numbers to currency ($0.00)
    private static final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();

    private double purchasePrice = 0.0;
    private double downPayment = 0.0;
    private double interestRate = 1.0;
    private double value = 0.0;
    private int duration = 1;

    private TextView textViewPurchasePriceSummary;
    private TextView textViewDownPaymentSummary;
    private TextView textViewInterestRateSummary;
    private TextView textViewLoanDurationSummary;
    private TextView textViewMonthlyPaymentSummary;
    private TextView textViewLDProgress1;
    private TextView textViewLDProgress2;
    private TextView textViewLDProgress3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    // Get access to elements from activity_main.xml
        textViewPurchasePriceSummary = findViewById(R.id.textViewPurchasePriceSummary);
        textViewDownPaymentSummary = findViewById(R.id.textViewDownPaymentSummary);
        textViewInterestRateSummary = findViewById(R.id.textViewInterestRateSummary);
        textViewLoanDurationSummary = findViewById(R.id.textViewLoanDurationSummary);
        textViewMonthlyPaymentSummary = findViewById(R.id.textViewMonthlyPaymentSummary);
        textViewLDProgress1 = findViewById(R.id.textViewLDProgress1);
        textViewLDProgress2 = findViewById(R.id.textViewLDProgress2);
        textViewLDProgress3 = findViewById(R.id.textViewLDProgress3);


        EditText editTextPurchasePrice = findViewById(R.id.editTextPurchasePrice);
        editTextPurchasePrice.addTextChangedListener(
                this.getEditableTextWatcher(editTextPurchasePrice, "PP"));

        EditText editTextDownPayment = findViewById(R.id.editTextDownPayment);
        editTextDownPayment.addTextChangedListener(
                this.getEditableTextWatcher(editTextDownPayment, "DP"));

        EditText editTextInterestRate = findViewById(R.id.editTextInterestRate);
        editTextInterestRate.addTextChangedListener(
                this.getEditableTextWatcher(editTextInterestRate, "IR"));

        SeekBar seekBarLoanDuration = findViewById(R.id.seekBarLoanDuration);
        seekBarLoanDuration.incrementProgressBy(10);
    // End Access to elements

        seekBarLoanDuration.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {

                // Forces incremental steps of 10 years for loanDuration
                progress = progress / 10;
                progress = progress * 10;

                duration = progress;    // How far has seekBar moved
                textViewLoanDurationSummary.setText(String.valueOf(progress));

                if(progress <= 15){
                    textViewLDProgress1.setText(String.valueOf(progress));
                    textViewLDProgress2.setText("");
                    textViewLDProgress3.setText("");
                }
                else if(progress > 15 && progress <= 25){
                    textViewLDProgress1.setText("");
                    textViewLDProgress2.setText(String.valueOf(progress));
                    textViewLDProgress3.setText("");
                }
                else if(progress > 25){
                    textViewLDProgress1.setText("");
                    textViewLDProgress2.setText("");
                    textViewLDProgress3.setText(String.valueOf(progress));
                }

                // Call Loan Method to calculate monthlyPayment when bar is moved
                textViewMonthlyPaymentSummary.setText(
                        String.valueOf(Loan(purchasePrice, downPayment, interestRate, duration))
                );
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    public TextWatcher getEditableTextWatcher(final TextView textView, final String type) {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                try {

                    if (s.length() != 0) {  // Prevents null pointer error
                                            // of accessing element that has been deleted
                        char firstChar = s.charAt(0);
                        value = Double.parseDouble(s.toString());
                        if (type.equals("PP")) {    // If typed in PurchasePrice row
                            purchasePrice = value;
                            if (value >= 0) {
                                textViewPurchasePriceSummary.setText(currencyFormat.format(value));
                            }
                        } else if (type.equals("DP")) {    // If typed in DownPayment row
                            downPayment = value;
                            if (value >= 0) {
                                textViewDownPaymentSummary.setText(currencyFormat.format(value));
                            }
                        } else if (type.equals("IR")) {    // If typed in InterestRate row
                            interestRate = value;
                            if (value >= 0) {
                                textViewInterestRateSummary.setText(String.valueOf(value) + "%");
                            }
                        }
                    }
                    else{   // Allows textView to reset to previous state if no entry found
                        if (type.equals("PP")) {
                            textViewPurchasePriceSummary.setText("");
                        }
                        else if (type.equals("DP")){
                            textViewDownPaymentSummary.setText("");
                        }
                        else if (type.equals("IR")){
                            textViewInterestRateSummary.setText("");
                        }
                    }
                } catch (NumberFormatException e) {
                    textView.setText("");
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        };
    }

    // Calculates monthlyPayment
    public String Loan(
            double purchasePrice, double downPayment, double interestRate, double duration)
    {
        final DecimalFormat decimalFormat = new DecimalFormat("0.00");

        double monthlyRate = interestRate / 1200;   // divided by 12 for monthly, 100 for % -> decimal
        double monthsDuration = duration * 12;      // * 12 for number of months duration
        double principal = purchasePrice - downPayment; // Actual loan amount from bank

        double monthlyPayment =
                principal *
                ((monthlyRate * (Math.pow((1 + monthlyRate), monthsDuration))) /
                (((Math.pow((1 + monthlyRate), monthsDuration)) - 1)));

        return currencyFormat.format(monthlyPayment);
    }
}
